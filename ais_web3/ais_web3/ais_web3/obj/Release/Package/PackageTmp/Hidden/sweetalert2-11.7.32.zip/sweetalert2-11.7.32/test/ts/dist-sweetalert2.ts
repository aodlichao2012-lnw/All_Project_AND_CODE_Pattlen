import Swal from 'sweetalert2/dist/sweetalert2.js'

Swal.fire()
